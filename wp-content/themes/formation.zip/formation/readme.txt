Formation is a responsive, highly customizable WordPress theme.

Theme instructions can be found at: http://www.templateexpress.com/formation-theme-instructions/

Fonts
-------------------------------------------
Genericons
vector icons embedded in a webfont designed to be clean and simple 
keeping with a generic aesthetic.
More info at http://genericons.com/

Source Sans Pro
This Font Software is licensed under the SIL Open Font License, Version 1.1.
More info available with a FAQ at: http://scripts.sil.org/OFL

Icons
--------------------------------------------
All icons are by Template Express and are free to use in all commercial projects.

License
--------------------------------------------
License: GNU General Public License v2.0
License URI: ?http://www.gnu.org/licenses/gpl-2.0.html


